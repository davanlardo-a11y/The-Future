package com.thefuture.app.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * pendingAction communicates back to the caller (MainActivity) what to do
 * once the correct PIN has been entered, since the actual state change
 * (unblock this app / turn hardcore off / drop the uninstall lock) lives
 * in Store and often needs an extra system call (e.g. opening the device
 * admin settings screen), which this composable does not know how to do.
 */
sealed class HardcorePendingAction {
    object DisableHardcore : HardcorePendingAction()
    object DisableUninstallLock : HardcorePendingAction()
}

@Composable
fun HardcoreScreen(
    hardcoreOn: Boolean,
    preventUninstall: Boolean,
    hasPin: Boolean,
    onRequestEnableHardcore: () -> Unit,
    onRequestDisableHardcore: () -> Unit,
    onRequestEnablePreventUninstall: () -> Unit,
    onRequestDisablePreventUninstall: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Text("Modo hardcore", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(
            "Bloqueo estricto. Solo quien tenga el PIN puede desactivarlo.",
            color = TextMuted, fontSize = 12.sp
        )
        Spacer(Modifier.height(16.dp))

        FutureCard(
            modifier = Modifier.padding(bottom = 14.dp),
            borderColor = if (hardcoreOn) Accent else BorderCol
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                IconBubble(bg = if (hardcoreOn) AccentDim else Panel2) {
                    Icon(Icons.Filled.Bolt, contentDescription = null, tint = TextPrimary)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Activar modo hardcore", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(if (hardcoreOn) "Activo" else "Inactivo", color = TextMuted, fontSize = 11.sp)
                }
                FutureToggle(on = hardcoreOn, onChange = {
                    if (it) onRequestEnableHardcore() else onRequestDisableHardcore()
                })
            }
        }

        FutureCard(modifier = Modifier.padding(bottom = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                IconBubble(bg = Panel2) {
                    Icon(
                        imageVector = if (preventUninstall) Icons.Filled.Shield else Icons.Filled.Warning,
                        contentDescription = null, tint = TextPrimary
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("No permitir desinstalar", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(if (preventUninstall) "Protegido" else "Sin proteger", color = TextMuted, fontSize = 11.sp)
                }
                FutureToggle(on = preventUninstall, onChange = {
                    if (it) onRequestEnablePreventUninstall() else onRequestDisablePreventUninstall()
                })
            }
        }

        Text(
            if (!hardcoreOn)
                "Al activar el modo hardcore, un amigo o familiar de confianza crea el PIN. Solo esa persona podra desactivar el modo, desbloquear apps o quitar la proteccion contra desinstalacion."
            else
                "El PIN lo tiene la persona que lo creo. Pidele a ella que lo introduzca para hacer cambios.",
            color = TextMuted, fontSize = 12.sp
        )
    }
}
