package com.thefuture.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thefuture.app.data.SleepSchedule
import java.util.Calendar

@Composable
fun RedLightScreen(
    redLightOn: Boolean,
    schedules: List<SleepSchedule>,
    onToggleRedLight: (Boolean) -> Unit,
    onAddSchedule: (String) -> Unit,
    onRemoveSchedule: (Long) -> Unit
) {
    var showAdd by remember { mutableStateOf(false) }
    var hour by remember { mutableStateOf(22) }
    var minute by remember { mutableStateOf(0) }

    Column(Modifier.fillMaxSize()) {
        Text("Luz roja", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("Prepara tu mente para dormir", color = TextMuted, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))

        FutureCard(modifier = Modifier.padding(bottom = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                IconBubble(bg = if (redLightOn) AccentDim else Panel2) {
                    Icon(Icons.Filled.NightsStay, contentDescription = null, tint = TextPrimary)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Modo luz roja", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(if (redLightOn) "Activado" else "Desactivado", color = TextMuted, fontSize = 11.sp)
                }
                FutureToggle(on = redLightOn, onChange = onToggleRedLight)
            }
        }

        Text("Horarios", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))

        schedules.forEach { s ->
            FutureCard(modifier = Modifier.padding(bottom = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text(s.time, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    Text("todos los dias", color = TextMuted, fontSize = 11.sp)
                    IconButton(onClick = { onRemoveSchedule(s.id) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Eliminar", tint = TextMuted)
                    }
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        PrimaryButton("Anadir horario") { showAdd = true }
    }

    if (showAdd) {
        FutureDialog(title = "Nuevo horario", onDismiss = { showAdd = false }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Hora: %02d:%02d".format(hour, minute), color = TextPrimary, fontSize = 16.sp)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(21, 22, 23, 0).forEach { h ->
                    OutlinedButton(onClick = { hour = h }) { Text("%02d:00".format(h)) }
                }
            }
            Spacer(Modifier.height(14.dp))
            PrimaryButton("Guardar horario") {
                onAddSchedule("%02d:%02d".format(hour, minute))
                showAdd = false
            }
        }
    }
}
