package com.thefuture.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thefuture.app.admin.MyDeviceAdminReceiver
import com.thefuture.app.data.BlockedApp
import com.thefuture.app.data.Store
import com.thefuture.app.service.RedLightScheduler
import com.thefuture.app.ui.*
import com.thefuture.app.util.AppInfo
import com.thefuture.app.util.InstalledAppsHelper

class MainActivity : ComponentActivity() {

    private lateinit var deviceAdminComponent: ComponentName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(applicationContext)
        deviceAdminComponent = ComponentName(this, MyDeviceAdminReceiver::class.java)
        RedLightScheduler.rescheduleAll(applicationContext, Store.schedules)

        setContent {
            FutureApp(
                activity = this,
                deviceAdminComponent = deviceAdminComponent
            )
        }
    }
}

@Composable
fun FutureApp(activity: ComponentActivity, deviceAdminComponent: ComponentName) {
    var tab by remember { mutableStateOf("home") }

    // pending action waiting on a correct PIN entry
    var pendingAction by remember { mutableStateOf<HardcorePendingAction?>(null) }
    var pendingAppId by remember { mutableStateOf<String?>(null) }
    var showAskPin by remember { mutableStateOf(false) }
    var showSetPin by remember { mutableStateOf(false) }

    val installedApps = remember { InstalledAppsHelper.getLaunchableApps(activity) }

    fun requestToggleApp(app: BlockedApp) {
        if (Store.hardcoreOn.value && app.blocked) {
            pendingAppId = app.packageName
            pendingAction = null
            showAskPin = true
        } else {
            Store.setAppBlocked(app.packageName, !app.blocked)
        }
    }

    fun requestEnableHardcore() {
        if (!Store.hasPin()) {
            showSetPin = true
        } else {
            Store.hardcoreOn.value = true
        }
    }

    fun requestDisableHardcore() {
        pendingAction = HardcorePendingAction.DisableHardcore
        pendingAppId = null
        showAskPin = true
    }

    fun requestEnablePreventUninstall() {
        Store.preventUninstall.value = true
        // Real OS-level protection: ask the user to activate Device Admin.
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, deviceAdminComponent)
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Esto evita que THE FUTURE se pueda desinstalar por accidente."
            )
        }
        activity.startActivity(intent)
    }

    fun requestDisablePreventUninstall() {
        pendingAction = HardcorePendingAction.DisableUninstallLock
        pendingAppId = null
        showAskPin = true
    }

    Surface(color = Bg, modifier = Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0E0E10)) {
                    val items = listOf(
                        Triple("home", "Inicio", Icons.Filled.Home),
                        Triple("habitos", "Habitos", Icons.Filled.Checklist),
                        Triple("luzroja", "Luz roja", Icons.Filled.NightsStay),
                        Triple("bloqueo", "Bloqueo", Icons.Filled.Lock),
                        Triple("hardcore", "Hardcore", Icons.Filled.Bolt)
                    )
                    items.forEach { (id, label, icon) ->
                        NavigationBarItem(
                            selected = tab == id,
                            onClick = { tab = id },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Accent,
                                selectedTextColor = Accent,
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted,
                                indicatorColor = Panel2
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(horizontal = 18.dp, vertical = 12.dp)
                    .fillMaxSize()
            ) {
                PermissionBanners(activity)

                when (tab) {
                    "home" -> HomeScreen(
                        streak = Store.streak.value,
                        xp = Store.xp.value,
                        habits = Store.habits,
                        hardcoreOn = Store.hardcoreOn.value,
                        redLightOn = Store.redLightOn.value,
                        blockedCount = Store.apps.count { it.blocked },
                        onToggleHabit = { Store.toggleHabit(it) }
                    )

                    "habitos" -> HabitsScreen(
                        habits = Store.habits,
                        onAdd = { Store.addHabit(it) },
                        onRemove = { Store.removeHabit(it) },
                        onToggle = { Store.toggleHabit(it) }
                    )

                    "luzroja" -> RedLightScreen(
                        redLightOn = Store.redLightOn.value,
                        schedules = Store.schedules,
                        onToggleRedLight = { Store.redLightOn.value = it },
                        onAddSchedule = {
                            Store.addSchedule(it)
                            RedLightScheduler.rescheduleAll(activity, Store.schedules)
                        },
                        onRemoveSchedule = { Store.removeSchedule(it) }
                    )

                    "bloqueo" -> BlockingScreen(
                        apps = Store.apps,
                        installedApps = installedApps,
                        hardcoreOn = Store.hardcoreOn.value,
                        onRequestToggle = { requestToggleApp(it) },
                        onAddApp = { info: AppInfo -> Store.addOrToggleApp(info.packageName, info.label) }
                    )

                    "hardcore" -> HardcoreScreen(
                        hardcoreOn = Store.hardcoreOn.value,
                        preventUninstall = Store.preventUninstall.value,
                        hasPin = Store.hasPin(),
                        onRequestEnableHardcore = { requestEnableHardcore() },
                        onRequestDisableHardcore = { requestDisableHardcore() },
                        onRequestEnablePreventUninstall = { requestEnablePreventUninstall() },
                        onRequestDisablePreventUninstall = { requestDisablePreventUninstall() }
                    )
                }
            }
        }
    }

    if (showSetPin) {
        SetPinDialog(
            onDismiss = { showSetPin = false },
            onConfirm = { pin ->
                Store.setPin(pin)
                Store.hardcoreOn.value = true
                showSetPin = false
            }
        )
    }

    if (showAskPin) {
        AskPinDialog(
            onDismiss = { showAskPin = false; pendingAction = null; pendingAppId = null },
            onConfirm = { attempt ->
                val ok = Store.checkPin(attempt)
                if (ok) {
                    pendingAppId?.let { Store.setAppBlocked(it, false) }
                    when (pendingAction) {
                        HardcorePendingAction.DisableHardcore -> Store.hardcoreOn.value = false
                        HardcorePendingAction.DisableUninstallLock -> Store.preventUninstall.value = false
                        null -> {}
                    }
                    pendingAction = null
                    pendingAppId = null
                }
                ok
            }
        )
    }
}

/**
 * Shows a small banner for each real Android permission this app needs
 * that is not yet granted, with a button that opens the exact system
 * screen to grant it. None of the blocking / red-light / anti-uninstall
 * features work until these are turned on by the user.
 */
@Composable
fun PermissionBanners(activity: ComponentActivity) {
    val overlayGranted = remember { mutableStateOf(Settings.canDrawOverlays(activity)) }
    val accessibilityGranted = remember { mutableStateOf(isAccessibilityServiceEnabled(activity)) }

    Column(modifier = Modifier.padding(bottom = 10.dp)) {
        if (!overlayGranted.value) {
            PermissionRow(
                text = "Permite dibujar sobre otras apps (necesario para la luz roja)."
            ) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + activity.packageName)
                )
                activity.startActivity(intent)
            }
        }
        if (!accessibilityGranted.value) {
            PermissionRow(
                text = "Activa el servicio de accesibilidad (necesario para bloquear apps)."
            ) {
                activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
    }
}

@Composable
fun PermissionRow(text: String, onClick: () -> Unit) {
    FutureCard(modifier = Modifier.padding(bottom = 8.dp), borderColor = Accent) {
        Text(text, color = TextPrimary, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        PrimaryButton("Activar") { onClick() }
    }
}

private fun isAccessibilityServiceEnabled(activity: ComponentActivity): Boolean {
    val manager = activity.getSystemService(AccessibilityManager::class.java) ?: return false
    val enabledServices = manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
    return enabledServices.any { it.resolveInfo.serviceInfo.packageName == activity.packageName }
}
