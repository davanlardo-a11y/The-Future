package com.thefuture.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thefuture.app.data.Habit

@Composable
fun HomeScreen(
    streak: Int,
    xp: Int,
    habits: List<Habit>,
    hardcoreOn: Boolean,
    redLightOn: Boolean,
    blockedCount: Int,
    onToggleHabit: (Long) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(bottom = 12.dp)) {
        Text("THE FUTURE", color = Accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(Modifier.height(2.dp))
        Text("Hola de nuevo", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Spacer(Modifier.height(18.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FutureCard(modifier = Modifier.weight(1f)) {
                Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Whatshot, contentDescription = null, tint = Accent)
                    Text("$streak", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                    Text("dias de racha", color = TextMuted, fontSize = 11.sp)
                }
            }
            FutureCard(modifier = Modifier.weight(1f)) {
                Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Star, contentDescription = null, tint = Accent)
                    Text("$xp", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                    Text("XP total", color = TextMuted, fontSize = 11.sp)
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        FutureCard {
            Text("Habitos de hoy", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            habits.take(3).forEach { h ->
                Row(
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                ) {
                    androidx.compose.material3.Checkbox(
                        checked = h.done,
                        onCheckedChange = { onToggleHabit(h.id) },
                        colors = androidx.compose.material3.CheckboxDefaults.colors(checkedColor = Accent)
                    )
                    Text(h.name, color = if (h.done) TextMuted else TextPrimary)
                }
            }
            if (habits.isNotEmpty() && habits.all { it.done }) {
                Text("Todos los habitos completados hoy!", color = Accent, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(14.dp))

        FutureCard {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                IconBubble {
                    Icon(
                        imageVector = if (hardcoreOn) Icons.Filled.Bolt else if (redLightOn) Icons.Filled.NightsStay else Icons.Filled.Lock,
                        contentDescription = null,
                        tint = TextPrimary
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        if (hardcoreOn) "Modo hardcore activo" else "Todo bajo control",
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                    Text(
                        "$blockedCount apps bloqueadas . luz roja ${if (redLightOn) "activada" else "apagada"}",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}
