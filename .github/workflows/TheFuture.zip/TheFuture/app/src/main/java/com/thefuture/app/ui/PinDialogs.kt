package com.thefuture.app.ui

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SetPinDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    FutureDialog(title = "Crear PIN del modo hardcore", onDismiss = onDismiss) {
        Text(
            "Dale el telefono a un amigo o familiar de confianza. Que escriba un PIN que tu no veas: sera el unico que pueda desactivar el modo hardcore.",
            color = TextMuted, fontSize = 12.sp
        )
        Spacer(Modifier.height(12.dp))
        PinTextField(value = pin, onValueChange = { pin = it; error = null }, label = "Nuevo PIN (min. 4 digitos)")
        Spacer(Modifier.height(10.dp))
        PinTextField(value = confirm, onValueChange = { confirm = it; error = null }, label = "Confirmar PIN")
        error?.let { Text(it, color = ErrorRed, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
        Spacer(Modifier.height(14.dp))
        PrimaryButton("Activar modo hardcore") {
            when {
                pin.length < 4 -> error = "El PIN debe tener al menos 4 digitos"
                pin != confirm -> error = "Los PIN no coinciden"
                else -> onConfirm(pin)
            }
        }
    }
}

@Composable
fun AskPinDialog(message: String = "Esta accion requiere el PIN creado por tu amigo o familiar.", onDismiss: () -> Unit, onConfirm: (String) -> Boolean) {
    var attempt by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    FutureDialog(title = "Introduce el PIN", onDismiss = onDismiss) {
        Text(message, color = TextMuted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        PinTextField(value = attempt, onValueChange = { attempt = it; error = null }, label = "PIN")
        error?.let { Text(it, color = ErrorRed, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
        Spacer(Modifier.height(14.dp))
        PrimaryButton("Confirmar") {
            val ok = onConfirm(attempt)
            if (!ok) error = "PIN incorrecto" else onDismiss()
        }
    }
}
