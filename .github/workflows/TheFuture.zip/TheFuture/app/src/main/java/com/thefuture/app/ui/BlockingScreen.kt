package com.thefuture.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thefuture.app.data.BlockedApp
import com.thefuture.app.util.AppInfo

@Composable
fun BlockingScreen(
    apps: List<BlockedApp>,
    installedApps: List<AppInfo>,
    hardcoreOn: Boolean,
    onRequestToggle: (BlockedApp) -> Unit,
    onAddApp: (AppInfo) -> Unit
) {
    var showPicker by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Text("Bloqueo de apps", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(
            if (hardcoreOn) "Modo hardcore activo: no puedes desbloquear sin el PIN" else "Bloquea y desbloquea cuando quieras",
            color = TextMuted, fontSize = 12.sp
        )
        Spacer(Modifier.height(16.dp))

        apps.forEach { a ->
            FutureCard(modifier = Modifier.padding(bottom = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    IconBubble(size = 36, bg = if (a.blocked) AccentDim else Panel2) {
                        Icon(
                            imageVector = if (a.blocked) Icons.Filled.Lock else Icons.Filled.LockOpen,
                            contentDescription = null, tint = TextPrimary
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(a.label, color = TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    FutureToggle(on = a.blocked, onChange = { onRequestToggle(a) })
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        PrimaryButton("Anadir app a bloquear") { showPicker = true }
    }

    if (showPicker) {
        FutureDialog(title = "Elige una app", onDismiss = { showPicker = false }) {
            LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                items(installedApps) { info ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Text(info.label, color = TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = {
                            onAddApp(info)
                            showPicker = false
                        }) { Text("Anadir", color = Accent) }
                    }
                }
            }
        }
    }
}
