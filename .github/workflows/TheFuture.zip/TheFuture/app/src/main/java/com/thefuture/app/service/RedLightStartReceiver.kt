package com.thefuture.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.thefuture.app.data.Store

class RedLightStartReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Store.init(context)
        if (!Store.redLightOn.value) return

        val serviceIntent = Intent(context, RedLightOverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }

        // Re-arm tomorrow's alarm for every schedule.
        RedLightScheduler.rescheduleAll(context, Store.schedules)
    }
}
