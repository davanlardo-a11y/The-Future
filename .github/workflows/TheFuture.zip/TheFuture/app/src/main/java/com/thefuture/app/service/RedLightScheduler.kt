package com.thefuture.app.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.thefuture.app.data.SleepSchedule
import java.util.Calendar

object RedLightScheduler {

    /** Schedules the overlay to start at each schedule's time, every day. */
    fun rescheduleAll(context: Context, schedules: List<SleepSchedule>) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        schedules.forEachIndexed { index, schedule ->
            scheduleOne(context, alarmManager, schedule, index)
        }
    }

    private fun scheduleOne(context: Context, alarmManager: AlarmManager, schedule: SleepSchedule, requestCode: Int) {
        val parts = schedule.time.split(":")
        if (parts.size != 2) return
        val hour = parts[0].toIntOrNull() ?: return
        val minute = parts[1].toIntOrNull() ?: return

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            if (before(Calendar.getInstance())) add(Calendar.DAY_OF_MONTH, 1)
        }

        val intent = Intent(context, RedLightStartReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        runCatching {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
        }
    }
}
