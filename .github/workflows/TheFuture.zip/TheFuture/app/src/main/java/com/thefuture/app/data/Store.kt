package com.thefuture.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class Habit(val id: Long, val name: String, var done: Boolean = false)
data class SleepSchedule(val id: Long, val time: String)
data class BlockedApp(val packageName: String, val label: String, var blocked: Boolean)

/**
 * Single in-memory + SharedPreferences-backed store for the whole app.
 * Kept intentionally simple (no Room / DI) so the project is easy to read
 * and extend. All state is exposed as Compose state so the UI recomposes
 * automatically when anything changes.
 */
object Store {
    private const val PREFS = "the_future_prefs"
    private lateinit var prefs: SharedPreferences
    private var initialized = false

    val habits = mutableStateListOf<Habit>()
    val xp = mutableStateOf(0)
    val streak = mutableStateOf(0)

    val redLightOn = mutableStateOf(true)
    val schedules = mutableStateListOf<SleepSchedule>()

    val apps = mutableStateListOf<BlockedApp>()

    val hardcoreOn = mutableStateOf(false)
    val pinHash = mutableStateOf<String?>(null)
    val preventUninstall = mutableStateOf(false)

    fun init(context: Context) {
        if (initialized) return
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        load()
        initialized = true
    }

    fun hash(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun hasPin(): Boolean = pinHash.value != null

    fun checkPin(pin: String): Boolean = pinHash.value != null && hash(pin) == pinHash.value

    fun setPin(pin: String) {
        pinHash.value = hash(pin)
        save()
    }

    fun addHabit(name: String) {
        habits.add(Habit(System.currentTimeMillis(), name))
        save()
    }

    fun removeHabit(id: Long) {
        habits.removeAll { it.id == id }
        save()
    }

    fun toggleHabit(id: Long) {
        val h = habits.find { it.id == id } ?: return
        val wasAllDone = habits.isNotEmpty() && habits.all { it.done }
        h.done = !h.done
        xp.value = (xp.value + if (h.done) 10 else -10).coerceAtLeast(0)
        val isAllDone = habits.isNotEmpty() && habits.all { it.done }
        if (!wasAllDone && isAllDone) streak.value += 1
        if (wasAllDone && !isAllDone) streak.value = (streak.value - 1).coerceAtLeast(0)
        save()
    }

    fun addSchedule(time: String) {
        schedules.add(SleepSchedule(System.currentTimeMillis(), time))
        save()
    }

    fun removeSchedule(id: Long) {
        schedules.removeAll { it.id == id }
        save()
    }

    fun addOrToggleApp(packageName: String, label: String) {
        val existing = apps.find { it.packageName == packageName }
        if (existing == null) {
            apps.add(BlockedApp(packageName, label, true))
        } else {
            existing.blocked = !existing.blocked
        }
        save()
    }

    fun setAppBlocked(packageName: String, blocked: Boolean) {
        apps.find { it.packageName == packageName }?.blocked = blocked
        save()
    }

    fun getBlockedPackageNames(): Set<String> = apps.filter { it.blocked }.map { it.packageName }.toSet()

    private fun save() {
        val editor = prefs.edit()
        editor.putInt("xp", xp.value)
        editor.putInt("streak", streak.value)
        editor.putBoolean("redLightOn", redLightOn.value)
        editor.putBoolean("hardcoreOn", hardcoreOn.value)
        editor.putBoolean("preventUninstall", preventUninstall.value)
        editor.putString("pinHash", pinHash.value)

        val habitsArr = JSONArray()
        habits.forEach {
            habitsArr.put(JSONObject().put("id", it.id).put("name", it.name).put("done", it.done))
        }
        editor.putString("habits", habitsArr.toString())

        val schedArr = JSONArray()
        schedules.forEach {
            schedArr.put(JSONObject().put("id", it.id).put("time", it.time))
        }
        editor.putString("schedules", schedArr.toString())

        val appsArr = JSONArray()
        apps.forEach {
            appsArr.put(
                JSONObject()
                    .put("packageName", it.packageName)
                    .put("label", it.label)
                    .put("blocked", it.blocked)
            )
        }
        editor.putString("apps", appsArr.toString())

        editor.apply()
    }

    private fun load() {
        xp.value = prefs.getInt("xp", 0)
        streak.value = prefs.getInt("streak", 0)
        redLightOn.value = prefs.getBoolean("redLightOn", true)
        hardcoreOn.value = prefs.getBoolean("hardcoreOn", false)
        preventUninstall.value = prefs.getBoolean("preventUninstall", false)
        pinHash.value = prefs.getString("pinHash", null)

        val storedHabits = prefs.getString("habits", null)
        habits.clear()
        if (storedHabits != null) {
            val arr = JSONArray(storedHabits)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                habits.add(Habit(o.getLong("id"), o.getString("name"), o.getBoolean("done")))
            }
        } else {
            habits.add(Habit(1, "Leer 10 paginas"))
            habits.add(Habit(2, "Meditar 5 minutos"))
            habits.add(Habit(3, "Sin redes antes de las 9am"))
        }

        val storedSchedules = prefs.getString("schedules", null)
        schedules.clear()
        if (storedSchedules != null) {
            val arr = JSONArray(storedSchedules)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                schedules.add(SleepSchedule(o.getLong("id"), o.getString("time")))
            }
        } else {
            schedules.add(SleepSchedule(1, "22:30"))
        }

        val storedApps = prefs.getString("apps", null)
        apps.clear()
        if (storedApps != null) {
            val arr = JSONArray(storedApps)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                apps.add(BlockedApp(o.getString("packageName"), o.getString("label"), o.getBoolean("blocked")))
            }
        }
    }
}
