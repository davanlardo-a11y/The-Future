package com.thefuture.app.admin

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/**
 * IMPORTANT (read this before relying on it):
 * Being an active Device Admin makes Android gray out the normal
 * "Uninstall" button for this app, so a casual attempt to remove it
 * from the Home screen / app info page is blocked. That protection is
 * real and works out of the box once the user activates admin rights.
 *
 * What it does NOT do: stop someone from going to
 * Settings > Security > Device admin apps and deactivating admin
 * manually, which then makes the app uninstallable again. Fully
 * preventing that requires the app to be set as Android's
 * "Device Owner" via provisioning (ADB or a QR-code managed setup),
 * which only works on a device with no existing accounts / a factory
 * reset device, and is not something an ordinary installed app can
 * do to itself. This class implements the strongest protection that
 * a normal installed app is technically allowed to have.
 */
class MyDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        return "Al desactivar esto, THE FUTURE podra ser desinstalada."
    }
}
