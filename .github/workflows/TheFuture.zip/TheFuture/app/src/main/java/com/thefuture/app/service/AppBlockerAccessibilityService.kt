package com.thefuture.app.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.thefuture.app.data.Store

/**
 * Watches window-state-changed events (i.e. "the user switched to app X")
 * and, if that package is in the user's blocked list, immediately launches
 * BlockOverlayActivity on top of it instead of letting it show.
 *
 * The user must turn this service on manually once, from
 * Settings > Accessibility > Installed apps > THE FUTURE. MainActivity
 * deep-links there for convenience.
 */
class AppBlockerAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        Store.init(applicationContext)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val packageName = event?.packageName?.toString() ?: return
        if (packageName == applicationContext.packageName) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        if (Store.getBlockedPackageNames().contains(packageName)) {
            val intent = Intent(this, BlockOverlayActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("blockedApp", packageName)
            }
            startActivity(intent)
        }
    }

    override fun onInterrupt() {}
}
