package com.thefuture.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.thefuture.app.data.Habit

@Composable
fun HabitsScreen(
    habits: List<Habit>,
    onAdd: (String) -> Unit,
    onRemove: (Long) -> Unit,
    onToggle: (Long) -> Unit
) {
    var showAdd by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        Text("Habitos", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("Cada habito completado suma 10 XP", color = TextMuted, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))

        if (habits.isEmpty()) {
            Text("Aun no tienes habitos. Anade el primero.", color = TextMuted, fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
        }

        habits.forEach { h ->
            FutureCard(modifier = Modifier.padding(bottom = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Checkbox(
                        checked = h.done,
                        onCheckedChange = { onToggle(h.id) },
                        colors = CheckboxDefaults.colors(checkedColor = Accent)
                    )
                    Text(
                        h.name,
                        color = if (h.done) TextMuted else TextPrimary,
                        textDecoration = if (h.done) TextDecoration.LineThrough else TextDecoration.None,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { onRemove(h.id) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Eliminar", tint = TextMuted)
                    }
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        PrimaryButton("Anadir habito") { showAdd = true; name = ""; error = null }
    }

    if (showAdd) {
        FutureDialog(title = "Nuevo habito", onDismiss = { showAdd = false }) {
            PlainTextField(value = name, onValueChange = { name = it; error = null }, label = "Ej. Dormir 8 horas")
            error?.let { Text(it, color = ErrorRed, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
            Spacer(Modifier.height(14.dp))
            PrimaryButton("Anadir") {
                if (name.isBlank()) {
                    error = "Escribe un nombre para el habito"
                } else {
                    onAdd(name.trim())
                    showAdd = false
                }
            }
        }
    }
}
