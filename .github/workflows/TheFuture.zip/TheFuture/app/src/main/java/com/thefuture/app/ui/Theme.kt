package com.thefuture.app.ui

import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF121214)
val Panel = Color(0xFF1C1C20)
val Panel2 = Color(0xFF222226)
val TextPrimary = Color(0xFFEDEBE6)
val TextMuted = Color(0xFF9A9A9E)
val Accent = Color(0xFFC2273D)
val AccentDim = Color(0xFF3A1620)
val BorderCol = Color(0xFF2C2C30)
val ErrorRed = Color(0xFFF28B8B)
