# THE FUTURE — proyecto Android (Kotlin + Jetpack Compose)

Este es el proyecto de Android Studio completo para compilar THE FUTURE como
una app real (.apk), con las 4 funciones que pediste: Hábitos + XP/racha,
Luz roja, Bloqueo de apps, y Modo Hardcore con PIN.

## Cómo compilarlo

1. Instala **Android Studio** (versión reciente, con Android SDK 34).
2. Abre esta carpeta (`TheFuture/`) como proyecto en Android Studio.
3. Espera a que Gradle sincronice (necesita internet la primera vez, para
   descargar Gradle 8.7 y las dependencias — eso es algo que yo no puedo
   hacer desde aquí porque este entorno no tiene conexión a internet ni el
   SDK de Android instalado, así que no pude compilar ni probar el `.apk`
   yo mismo).
4. Conecta tu celular por USB con "Depuración USB" activada, o usa un
   emulador, y presiona **Run**.
5. Android Studio generará el `.apk` en
   `app/build/outputs/apk/debug/app-debug.apk`. Para un `.apk` para
   compartir/instalar fuera de Android Studio, usa
   **Build > Generate Signed Bundle / APK**.

## Qué es real y qué necesitas activar en el celular

Todo el código usa APIs reales de Android — no es una simulación — pero
cada función necesita que el usuario active un permiso especial la
primera vez (Android lo exige así por seguridad). La app te avisa con un
banner arriba y un botón que abre la pantalla exacta:

- **Hábitos, XP y racha**: funcionan directo, sin permisos. Se guardan en
  el celular (SharedPreferences) y sobreviven a cerrar la app.
- **Luz roja**: dibuja una capa roja translúcida sobre toda la pantalla a
  la hora que configures (AlarmManager + un Service en primer plano).
  Necesita el permiso "Dibujar sobre otras apps"
  (`SYSTEM_ALERT_WINDOW` / `Settings.ACTION_MANAGE_OVERLAY_PERMISSION`).
- **Bloqueo de apps**: usa un `AccessibilityService` que detecta cuándo
  abres una app de tu lista y la tapa con una pantalla de bloqueo.
  Necesita que actives el servicio de accesibilidad de THE FUTURE en
  Ajustes > Accesibilidad (Android obliga a hacerlo manualmente, ningún
  desarrollador puede activarlo por ti).
- **Modo hardcore + PIN**: es lógica de la app (Store.kt), no requiere
  permiso especial. Una vez activo, desbloquear una app o apagar el modo
  exige el PIN que haya creado la otra persona.

## El límite real de "no permitir desinstalar"

Aquí quiero ser honesto para que no haya sorpresas:

- Al activar esta opción, la app pide activarse como **Administrador del
  dispositivo** (Device Admin). Esto es real: mientras esté activo,
  Android **bloquea el botón normal de "Desinstalar"** en la información
  de la app y en el launcher.
- Lo que Android **no permite** que ninguna app haga por sí misma es
  impedir que alguien vaya a Ajustes > Seguridad > Apps de administración
  del dispositivo y lo desactive manualmente — eso siempre queda
  disponible para el dueño del celular. Bloquear también esa puerta
  requeriría que la app sea "Device Owner", algo que solo se puede
  configurar en un celular recién restablecido de fábrica mediante
  aprovisionamiento (ADB o código QR), no algo que una app instalada
  normalmente pueda activar sola.
- En resumen: la protección es real y sirve para evitar una
  desinstalación accidental o impulsiva, pero no es infalible al 100% si
  alguien busca específicamente cómo quitarla en los ajustes del sistema.

## Estructura del proyecto

```
app/src/main/java/com/thefuture/app/
  data/Store.kt                     estado global + persistencia (hábitos, XP, racha, PIN, apps bloqueadas)
  service/AppBlockerAccessibilityService.kt   detecta la app en primer plano y la bloquea
  service/BlockOverlayActivity.kt   pantalla que se muestra en vez de la app bloqueada
  service/RedLightOverlayService.kt  dibuja el overlay rojo
  service/RedLightScheduler.kt / RedLightStartReceiver.kt   alarmas diarias
  admin/MyDeviceAdminReceiver.kt    protección anti-desinstalación
  util/InstalledAppsHelper.kt       lista de apps instaladas para elegir cuáles bloquear
  ui/*                              todas las pantallas (Compose), estilo oscuro + rojo de la presentación
  MainActivity.kt                   navegación inferior + banners de permisos + lógica de PIN
```

## Posibles ajustes al compilar

No pude ejecutar un build real aquí, así que si Android Studio marca
algún error pequeño (versión de una librería, un ícono de
`material-icons-extended` con nombre distinto, etc.), son ajustes
menores — la arquitectura y la lógica de negocio (hábitos, XP, racha,
horarios, bloqueo, PIN) ya están completas y no deberían cambiar.
